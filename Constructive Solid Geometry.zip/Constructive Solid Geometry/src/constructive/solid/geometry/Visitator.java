
package constructive.solid.geometry;


public interface Visitator
{
    public void visit(Shape shape);
}
